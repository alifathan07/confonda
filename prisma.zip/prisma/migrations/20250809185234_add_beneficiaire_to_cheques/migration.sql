/*
  Warnings:

  - You are about to drop the column `benificiaire` on the `cheque` table. All the data in the column will be lost.
  - You are about to drop the column `benificiaire` on the `effet` table. All the data in the column will be lost.
  - Added the required column `beneficiaire` to the `Cheque` table without a default value. This is not possible if the table is not empty.
  - Added the required column `beneficiaire` to the `Effet` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `cheque` DROP COLUMN `benificiaire`,
    ADD COLUMN `beneficiaire` VARCHAR(191) NOT NULL;

-- AlterTable
ALTER TABLE `effet` DROP COLUMN `benificiaire`,
    ADD COLUMN `beneficiaire` VARCHAR(191) NOT NULL;
