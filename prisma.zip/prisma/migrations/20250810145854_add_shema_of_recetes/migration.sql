/*
  Warnings:

  - You are about to drop the column `fournisseurId` on the `recavenir` table. All the data in the column will be lost.
  - Added the required column `clientId` to the `Recavenir` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE `recavenir` DROP FOREIGN KEY `Recavenir_fournisseurId_fkey`;

-- DropIndex
DROP INDEX `Recavenir_fournisseurId_fkey` ON `recavenir`;

-- AlterTable
ALTER TABLE `recavenir` DROP COLUMN `fournisseurId`,
    ADD COLUMN `clientId` INTEGER NOT NULL;

-- CreateTable
CREATE TABLE `Client` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(191) NOT NULL,
    `email` VARCHAR(191) NULL,
    `ice` VARCHAR(191) NOT NULL,
    `identifFiscal` VARCHAR(191) NOT NULL,
    `telFournisseur` VARCHAR(191) NOT NULL,
    `contact` VARCHAR(191) NOT NULL,
    `telContact` VARCHAR(191) NOT NULL,
    `address` VARCHAR(191) NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    UNIQUE INDEX `Client_ice_key`(`ice`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `Recavenir` ADD CONSTRAINT `Recavenir_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
