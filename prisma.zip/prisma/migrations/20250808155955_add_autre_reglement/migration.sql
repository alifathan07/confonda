/*
  Warnings:

  - You are about to drop the column `nom` on the `autrereglement` table. All the data in the column will be lost.
  - Added the required column `designation` to the `AutreReglement` table without a default value. This is not possible if the table is not empty.
  - Added the required column `obs` to the `AutreReglement` table without a default value. This is not possible if the table is not empty.
  - Added the required column `statut` to the `AutreReglement` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `autrereglement` DROP COLUMN `nom`,
    ADD COLUMN `dateReglement` DATETIME(3) NULL,
    ADD COLUMN `designation` VARCHAR(191) NOT NULL,
    ADD COLUMN `obs` VARCHAR(191) NOT NULL,
    ADD COLUMN `statut` VARCHAR(191) NOT NULL,
    MODIFY `dateEcheance` DATETIME(3) NULL;
