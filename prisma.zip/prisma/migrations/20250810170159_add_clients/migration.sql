/*
  Warnings:

  - You are about to drop the column `telFournisseur` on the `client` table. All the data in the column will be lost.
  - Added the required column `telClient` to the `Client` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `client` DROP COLUMN `telFournisseur`,
    ADD COLUMN `telClient` VARCHAR(191) NOT NULL;
