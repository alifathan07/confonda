/*
  Warnings:

  - Added the required column `montantPaye` to the `Effet` table without a default value. This is not possible if the table is not empty.
  - Added the required column `reste` to the `Effet` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `effet` ADD COLUMN `montantPaye` DOUBLE NOT NULL,
    ADD COLUMN `reste` DOUBLE NOT NULL;
