/*
  Warnings:

  - You are about to drop the column `montantPaye` on the `effet` table. All the data in the column will be lost.
  - You are about to drop the column `reste` on the `effet` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `cheque` ADD COLUMN `obs` VARCHAR(191) NULL;

-- AlterTable
ALTER TABLE `effet` DROP COLUMN `montantPaye`,
    DROP COLUMN `reste`,
    MODIFY `obs` VARCHAR(191) NULL;
