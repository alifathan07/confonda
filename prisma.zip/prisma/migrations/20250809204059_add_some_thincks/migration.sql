/*
  Warnings:

  - Added the required column `banqueId` to the `AutreReglement` table without a default value. This is not possible if the table is not empty.
  - Added the required column `beneficiaire` to the `AutreReglement` table without a default value. This is not possible if the table is not empty.
  - Added the required column `fournisseurId` to the `AutreReglement` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `autrereglement` ADD COLUMN `banqueId` INTEGER NOT NULL,
    ADD COLUMN `beneficiaire` VARCHAR(191) NOT NULL,
    ADD COLUMN `fournisseurId` INTEGER NOT NULL;

-- AddForeignKey
ALTER TABLE `AutreReglement` ADD CONSTRAINT `AutreReglement_fournisseurId_fkey` FOREIGN KEY (`fournisseurId`) REFERENCES `Fournisseur`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AutreReglement` ADD CONSTRAINT `AutreReglement_banqueId_fkey` FOREIGN KEY (`banqueId`) REFERENCES `Banque`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
