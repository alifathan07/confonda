/*
  Warnings:

  - Added the required column `obs` to the `Effet` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `effet` ADD COLUMN `obs` VARCHAR(191) NOT NULL;
