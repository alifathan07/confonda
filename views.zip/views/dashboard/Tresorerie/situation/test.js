<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="description" content="Cheques" />
  <meta name="author" content="Confonda" />
  <title>Situation Bancaire
  </title>
  <link href="/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css" />
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,300,400,600,700,800,900" rel="stylesheet" />
  <link href="/css/sb-admin-2.min.css" rel="stylesheet" />
  <style>
    .excel-table th.dragging {
                  opacity: 0.5;
                  background: #b3d4fc;
                }
                .excel-table th.drag-over {
                  outline: 2px dashed #4a90e2;
                  background: #eaf3ff;
                }
                .excel-delete-btn {
                  background: #e74c3c;
                  color: #fff;
                  border: none;
                  border-radius: 4px;
                  width: 32px;
                  height: 32px;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  font-size: 16px;
                  cursor: pointer;
                  transition: background 0.2s, box-shadow 0.2s;
                  outline: none;
                  box-shadow: none;
                  padding: 0;
                }
                .excel-delete-btn:hover, .excel-delete-btn:focus {
                  background: #c0392b;
                  box-shadow: 0 0 0 2px #e74c3c33;
                }
                .excel-delete-btn i {
                  pointer-events: none;
                }
                .excel-dirty-row td {
                  background: #fffbe6 !important;
                }
    /* Enhanced Excel-like Table */
    .excel-table {
      border-collapse: separate;
      border-spacing: 0;
      width: 100%;
      font-size: 15px;
      font-family: Calibri, 'Segoe UI', sans-serif;
      table-layout: fixed;
      background-color: #fff;
    }
  
    .excel-table th,
    .excel-table td {
      border: 1px solid #d0d7de;
      padding: 10px 14px;
      min-width: 120px;
      height: 36px;
      text-align: left;
      vertical-align: middle;
      background-color: #fff;
      transition: background 0.2s;
      outline: none;
      color: #222;
    }
  
    .excel-table th {
      background-color: #f6f8fa;
      font-weight: 700;
      color: #0d1a4a;
      font-size: 16px;
    }
  
    .excel-table td[contenteditable="true"]:focus {
      background-color: #dff0ff;
      border: 2px solid #4a90e2;
    }
  
    .excel-table tr:hover td {
      background-color: #e3f0ff;
    }
  
    .excel-table td::selection {
      background-color: #cce5ff;
    }
  
    .excel-dirty-row td {
      background: #fff7b2 !important;
    }
  
    .excel-delete-btn {
      background: #e74c3c;
      color: white;
      border: none;
      width: 30px;
      height: 30px;
      font-size: 14px;
      border-radius: 4px;
      transition: background 0.2s ease-in-out;
      display: flex;
      align-items: center;
      justify-content: center;
    }
  
    .excel-delete-btn:hover {
      background: #c0392b;
    }
  
    .excel-table th.dragging {
      opacity: 0.5;
      background-color: #cce5ff;
    }
  
    .excel-table th.drag-over {
      outline: 2px dashed #4a90e2;
      background-color: #eaf3ff;
    }
  
    .excel-save-btn {
      margin-top: 15px;
      font-weight: bold;
      letter-spacing: 0.3px;
    }
  </style>
  
</head>
<body id="page-top"> 
  <div id="wrapper">
    <%- include('../../../layouts/sidebar') %>
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <%- include('../../../layouts/topbar') %>

<div class="container-fluid">
<h1 class="h3 mb-4 text-gray-800">Situation Bancaire</h1>

<!-- Daily Solde Input Table -->
<form id="soldeForm" action="/tresorerie/situation" method="POST">
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Soldes Bancaires</h6>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered table-hover text-right" id="situationBancaire">
          <thead class="thead-light" >
            <tr>
              <th class="text-left">Banque</th>
              <th class="text-center">SOLDE POSITIF</th>
              <th class="text-center">SOLDE NEGATIF</th>
              <th></th> <!-- Empty spacer -->
              <th class="text-center">DETTE MOYEN LONG TERME</th>
              <th class="text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
              <% banques.forEach((b, index) => { %>
                <tr>
                  <td class="text-left"><strong><%= b.name %></strong></td>
                  <td>
                      <input
                        type="number"
                        name="positive[]"
                        step="0.01"
                        value="<%= b.positive?.toFixed(2) %>"
                        class="form-control text-right"
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        name="negative[]"
                        step="0.01"
                        value="<%= b.negative?.toFixed(2) %>"
                        class="form-control text-right"
                      />
                    </td>
                    <td></td>
                    <td>
                      <input
                        type="number"
                        name="dmlt[]"
                        step="0.01"
                        value="<%= b.dmlt?.toFixed(2) %>"
                        class="form-control text-right"
                      />
                    </td>
                    <td>
                      <button type="button" class="btn btn-danger" onclick="deleteBanque(<%= b.id %>)">Supprimer</button>
                    </td>
                    
                  <input type="hidden" name="banqueId[]" value="<%= b.id %>" />
                </tr>
              <% }); %>
            </tbody>
            
          <tfoot class="font-weight-bold">
            <tr>
              <td>TOTAL</td>
              <td>
                  <input type="text" name="totalPositive" class="form-control text-right" 
                  value="<%= (banques.reduce((acc, b) => acc + b.positive, 0)).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) %>" 
                  readonly />
                                </td>
              <td>
                  
                  <input type="text" name="totalNegative" class="form-control text-right" 
                  value="<%= (banques.reduce((acc, b) => acc + b.negative, 0)).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) %>" 
                  readonly />
              </td>
              <td></td>
              <td>
                  <input type="text" name="totalDmlt" class="form-control text-right" 
                  value="<%= (banques.reduce((acc, b) => acc + b.dmlt, 0)).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) %>" 
                  readonly />
              </td>
              <td></td>
            </tr>
          </tfoot>
        </table>

        
      </div>
      
    </div>
    <div class="card-footer">
      <button type="button" class="btn btn-success mr-2" onclick="openBanqueModal()">Ajouter Banque</button>
      <button type="submit" class="btn btn-primary" hidden>Mettre à jour</button>
    </div>
  </div>
</form>




  <!-- <--------------- recettes à venir ------------------> 
  <div class="card shadow mb-4">
    <div class="card-header py-3 d-flex justify-content-center align-items-center">
      <h2 class="m-0 font-weight-bold text-primary">Recettes à venir</h2>
    </div>
    <div class="card-header py-3 d-flex justify-content-center align-items-center">
      <form class="form-inline">
        <label class="mr-2">Statut:</label>
        <select id="statutFilterRecette" class="form-control w-auto d-inline-block mr-2">
          <option value="">Tous</option>
          <option value="échu">échu</option>
          <option value="impayé">Impayé</option>
          <option value="non échu">Non échu</option>
        </select>
        <label class="mr-2">Client:</label>
        <select id="clientFilterRecette" class="form-control w-auto d-inline-block mr-2">
          <option value="">Tous</option>
          <% clients.forEach(c => { %>
            <option value="<%= c.name %>"><%= c.name %></option>
          <% }) %>
        </select>
        <label class="mr-2">Banque:</label>
        <select id="banqueFilterRecette" class="form-control w-auto d-inline-block mr-2">
          <option value="">Tous</option>
          <% banques.forEach(b => { %>
            <option value="<%= b.name %>"><%= b.name %></option>
          <% }) %>
        </select>
      </form>
    </div>
    <div class="card-header py-3 d-flex justify-content-center align-items-center">
      <form class="form-inline" method="GET">
        <input type="date" name="from" class="form-control mr-2" value="01/01/2020" hidden>
        <input type="date" name="to" id="to" class="form-control mr-2" value="" hidden>
        <button class="btn btn-primary btn-sm" type="submit">Annuler Filtre</button>
      </form>
    </div>
    <div class="card-body">
      <% if (recavenirs.length === 0) { %>
        <p class="text-muted">Aucun recette à venir trouvé pour cette période.</p>
      <% } else { %>
        <div class="table-responsive">
            <table id="recavenirsTable" class="table table-bordered table-striped text-right">
              <thead class="thead-light">
                <tr>
                  <th>Designation</th>
                  <th>Montant</th>
                  <th>Date Echéance</th>
                  <th>Statut</th>
                  <th>Date de paiement</th>
                  <th>Client</th>
                  <th>Banque</th>
                </tr>
              </thead>
              <tbody>
                <% recavenirs.forEach(c => { %>
                  <tr class="recavenir-row" data-client="<%= c.client.name %>" data-banque="<%= c.banque.name %>" data-statut="<%= c.statut %>">
                    <td class="text-left"><%= c.designation %></td>
                    <td class="montant"><%= c.montant.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) %></td>
                    <td><%= new Date(c.dateEcheance).toLocaleDateString() %></td>
                    <td><%= c.statut %></td>
                    <td><%= new Date(c.dateReglement).toLocaleDateString() %></td>
                    <td><%= c.client.name %></td>
                    <td><%= c.banque.name %></td>
                  </tr>
                <% }); %>
              </tbody>
              
              <% let totalMontantRecavenirs = recavenirs.reduce((acc, c) => acc + c.montant, 0) %>
              <tfoot class="font-weight-bold">
                <tr>
                  <td class="text-left">TOTAL</td>
                  <td id="totalMontantCellRecavenirs"><%= totalMontantRecavenirs.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) %></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
      <% } %>
    </div>
  </div>

<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary d-flex align-items-center">
      Total Général Au
      <input type="date" name="to" class="form-control ml-2 mr-3" value="<%= !to ? new Date().toISOString().split('T')[0] : to %>" style="width: 150px;" disabled>
    </h6>
  </div>
  <div class="card-body">
    <div class="row">
      <div class="col-md-4">
        <div class="card border-left-info shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Chèques</div>
                <div class="h5 mb-0 font-weight-bold text-gray-800" id="displayTotalCheques"><%= (cheques.reduce((acc, c) => acc + c.montant, 0)).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) %></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-money-check fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card border-left-warning shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Total Effets</div>
                <div class="h5 mb-0 font-weight-bold text-gray-800" id="displayTotalEffets"><%= (effets.reduce((acc, e) => acc + e.montant, 0)).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) %></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-file-invoice fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card border-left-info shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Recettes à venir</div>
                <div class="h5 mb-0 font-weight-bold text-gray-800" id="displayTotalRecavenirs"><%= (recavenirs.reduce((acc, c) => acc + c.montant, 0)).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) %></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-money-check fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card border-left-success shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total Général</div>
                <div class="h5 mb-0 font-weight-bold text-gray-800" id="displayTotalGeneral"><%= ((cheques.reduce((acc, c) => acc + c.montant, 0)) + (effets.reduce((acc, e) => acc + e.montant, 0)) + (payavenirs.reduce((acc, c) => acc + c.montant, 0))).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) %></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-calculator fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Banque Modal -->
<div class="modal fade" id="banqueModal" tabindex="-1" role="dialog" aria-labelledby="banqueModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <form id="banqueForm" action="/tresorerie/situation/create/banque" method="POST">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Ajouter une Banque</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span>&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label for="name">Nom Banque</label>
            <input type="text" class="form-control" name="name" required>
          </div>
          <div class="form-group">
            <label for="rib">RIB</label>
            <input type="number" class="form-control" name="rib" required>
          </div>
          <div class="form-group">
            <label for="agence">Agence</label>
            <input type="text" class="form-control" name="agence" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Enregistrer</button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Filter for cheques en circulation -->
<div class="card shadow mb-4">
  <div class="card-header py-3 d-flex justify-content-center align-items-center">
    <h2 class="m-0 font-weight-bold text-primary">Chèques en circulation</h2>
  </div>
  <div class="card-header py-3 d-flex justify-content-center align-items-center">
    <form class="form-inline">
      <label class="mr-2">Statut:</label>
      <select id="statutFilterCheques" class="form-control w-auto d-inline-block mr-2">
        <option value="">Tous</option>
        <option value="En circulation">En Circulation</option>
        <option value="Impayé">Impayé</option>
      </select>
      <label class="mr-2">Fournisseur:</label>
      <select id="fournisseurFilterCheques" class="form-control w-auto d-inline-block mr-2">
        <option value="">Tous</option>
        <% fournisseurs.forEach(f => { %>
          <option value="<%= f.name %>"><%= f.name %></option>
        <% }) %>
      </select>
      <label class="mr-2">Banque:</label>
      <select id="banqueFilterCheques" class="form-control w-auto d-inline-block mr-2">
        <option value="">Tous</option>
        <% banques.forEach(b => { %>
          <option value="<%= b.name %>"><%= b.name %></option>
        <% }) %>
      </select>
    </form>
  </div>
  <div class="card-header py-3 d-flex justify-content-center align-items-center">
    <form class="form-inline" method="GET">
      <input type="date" name="from" class="form-control mr-2" value="01/01/2020" hidden>
      <input type="date" name="to" id="to" class="form-control mr-2" value="" hidden>
      <button class="btn btn-primary btn-sm" type="submit">Annuler Filtre</button>
    </form>
  </div>
  <div class="card-body">
    <% if (cheques.length === 0) { %>
      <p class="text-muted">Aucun chèque trouvé pour cette période.</p>
    <% } else { %>
      <div class="table-responsive">
          <table id="chequesTable" class="table table-bordered table-striped text-right">
            <thead class="thead-light">
              <tr>
                <th class="text-left">Numéro</th>
                <th>Montant</th>
                <th>Date Échéance</th>
                <th>Bénéficiaire</th>
                <th>Banque</th>
                <th>Statut</th>
              </tr>
            </thead>
            <tbody>
              <% cheques.forEach(c => { %>
                <tr class="cheque-row" data-fournisseur="<%= c.beneficiaire %>" data-banque="<%= c.banque.name %>" data-statut="<%= c.statut %>">
                  <td class="text-left"><%= c.numero %></td>
                  <td class="montant"><%= c.montant.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) %></td>
                  <td><%= new Date(c.dateEcheance).toLocaleDateString() %></td>
                  <td><%= c.beneficiaire %></td>
                  <td><%= c.banque.name %></td>
                  <td><%= c.statut %></td>
                </tr>
              <% }); %>
            </tbody>
            
            <% let totalMontantCheques = cheques.reduce((acc, c) => acc + c.montant, 0) %>
            <tfoot class="font-weight-bold">
              <tr>
                <td class="text-left">TOTAL</td>
                <td id="totalMontantCellCheques"><%= totalMontantCheques.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) %></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
    <% } %>
  </div>
</div>

<div class="card shadow mb-4">
  <div class="card-header py-3 d-flex justify-content-center align-items-center">
    <h3 class="m-0 font-weight-bold text-primary text-center">Effets en circulation</h3>
  </div>
  <div class="card-header py-3 d-flex justify-content-center align-items-center">
    <form class="form-inline">
      <label class="mr-2">Statut:</label>
      <select id="statutFilterEffets" class="form-control w-auto d-inline-block ml-2">
        <option value="">Tous</option>
        <option value="En circulation">En Circulation</option>
        <option value="Impayé">Impayé</option>
      </select>
      <label class="mr-2">Fournisseur:</label>
      <select id="fournisseurFilterEffets" class="form-control w-auto d-inline-block ml-2">
        <option value="">Tous</option>
        <% fournisseurs.forEach(f => { %>
          <option value="<%= f.name %>"><%= f.name %></option>
        <% }) %>
      </select>
      <label class="mr-2">Banque:</label>
      <select id="banqueFilterEffets" class="form-control w-auto d-inline-block ml-2">
        <option value="">Tous</option>
        <% banques.forEach(b => { %>
          <option value="<%= b.name %>"><%= b.name %></option>
        <% }) %>
      </select>
    </form>
  </div>
  <div class="card-header py-3 d-flex justify-content-center align-items-center">
    <button class="btn btn-primary btn-block" type="button">Annuler Filtre</button>
  </div>
  <div class="card-body">
    <% if (effets.length === 0) { %>
      <p class="text-muted">Aucun effet trouvé pour cette période.</p>
    <% } else { %>
      <div class="table-responsive">
          <table id="effetsTable" class="table table-bordered table-striped text-right">
            <thead class="thead-light">
              <tr>
                <th class="text-left">Numéro</th>
                <th>Montant</th>
                <th>Date Échéance</th>
                <th>Bénéficiaire</th>
                <th>Banque</th>
                <th>Statut</th>
              </tr>
            </thead>
            <tbody>
              <% effets.forEach(e => { %>
                <tr class="effet-row" data-fournisseur="<%= e.beneficiaire %>" data-banque="<%= e.banque.name %>" data-statut="<%= e.statut %>">
                  <td class="text-left"><%= e.numero %></td>
                  <td class="montant"><%= e.montant.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) %></td>
                  <td><%= new Date(e.dateEcheance).toLocaleDateString() %></td>
                  <td><%= e.beneficiaire %></td>
                  <td><%= e.banque.name %></td>
                  <td><%= e.statut %></td>
                </tr>
              <% }); %>
            </tbody>
            
            <% let totalMontantEffets = effets.reduce((acc, e) => acc + e.montant, 0) %>
            <tfoot class="font-weight-bold">
              <tr>
                <td class="text-left">TOTAL</td>
                <td id="totalMontantCellEffets"><%= totalMontantEffets.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) %></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
    <% } %>
  </div>
</div>


<!-- <--------------- paiment à venir ------------------> 
<div class="card shadow mb-4">
  <div class="card-header py-3 d-flex justify-content-center align-items-center">
    <h2 class="m-0 font-weight-bold text-primary">Paiment à venir</h2>
  </div>
  <div class="card-header py-3 d-flex justify-content-center align-items-center">
    <form class="form-inline">
      <label class="mr-2">Statut:</label>
      <select id="statutFilterPaiment" class="form-control w-auto d-inline-block mr-2">
        <option value="">Tous</option>
        <option value="échu">échu</option>
        <option value="impayé">Impayé</option>
        <option value="non échu">Non échu</option>
      </select>
      <label class="mr-2">Fournisseur:</label>
      <select id="fournisseurFilterPaiment" class="form-control w-auto d-inline-block mr-2">
        <option value="">Tous</option>
        <% fournisseurs.forEach(f => { %>
          <option value="<%= f.name %>"><%= f.name %></option>
        <% }) %>
      </select>
      <label class="mr-2">Banque:</label>
      <select id="banqueFilterPaiment" class="form-control w-auto d-inline-block mr-2">
        <option value="">Tous</option>
        <% banques.forEach(b => { %>
          <option value="<%= b.name %>"><%= b.name %></option>
        <% }) %>
      </select>
    </form>
  </div>
  <div class="card-header py-3 d-flex justify-content-center align-items-center">
    <form class="form-inline" method="GET">
      <input type="date" name="from" class="form-control mr-2" value="01/01/2020" hidden>
      <input type="date" name="to" id="to" class="form-control mr-2" value="" hidden>
      <button class="btn btn-primary btn-sm" type="submit">Annuler Filtre</button>
    </form>
  </div>
  <div class="card-body">
    <% if (payavenirs.length === 0) { %>
      <p class="text-muted">Aucun paiment à venir trouvé pour cette période.</p>
    <% } else { %>
      <div class="table-responsive">
          <table id="payavenirsTable" class="table table-bordered table-striped text-right">
            <thead class="thead-light">
              <tr>
                <th>Designation</th>
                <th>Montant</th>
                <th>Date Echéance</th>
                <th>Statut</th>
                <th>Date de paiement</th>
                <th>Fournisseur</th>
                <th>Banque</th>
              </tr>
            </thead>
            <tbody>
              <% payavenirs.forEach(c => { %>
                <tr class="payavenir-row" data-fournisseur="<%= c.fournisseur.name %>" data-banque="<%= c.banque.name %>" data-statut="<%= c.statut %>">
                  <td class="text-left"><%= c.designation %></td>
                  <td class="montant"><%= c.montant.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) %></td>
                  <td><%= new Date(c.dateEcheance).toLocaleDateString() %></td>
                  <td><%= c.statut %></td>
                  <td><%= new Date(c.dateReglement).toLocaleDateString() %></td>
                  <td><%= c.fournisseur.name %></td>
                  <td><%= c.banque.name %></td>
                </tr>
              <% }); %>
            </tbody>
            
            <% let totalMontantPayavenirs = payavenirs.reduce((acc, c) => acc + c.montant, 0) %>
            <tfoot class="font-weight-bold">
              <tr>
                <td class="text-left">TOTAL</td>
                <td id="totalMontantCellPayavenirs"><%= totalMontantPayavenirs.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) %></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
    <% } %>
  </div>
</div>



<!-- Download Buttons -->
<div class="card shadow mb-4">
  <div class="card-body text-center">
    <button class="btn btn-success mr-2" onclick="downloadFullPagePDF()">Télécharger PDF Complet</button>
    <button class="btn btn-info mr-2" onclick="downloadChequesPDF()">Télécharger PDF Chèques</button>
    <button class="btn btn-warning mr-2" onclick="downloadEffetsPDF()">Télécharger PDF Effets</button>
    <button class="btn btn-primary mr-2" onclick="downloadPayavenirsPDF()">Télécharger PDF Paiment à venir
    </button>
    <button class="btn btn-primary mr-2" onclick="downloadRecettesPDF()">Télécharger PDF Recettes
    </button>
  </div>
</div>

      </div>
    </div>
  </div>
</body>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Get filter elements for cheques
    const statutSelectCheques = document.getElementById('statutFilterCheques');
    const fournisseurSelectCheques = document.getElementById('fournisseurFilterCheques');
    const banqueSelectCheques = document.getElementById('banqueFilterCheques');
    
    // Get filter elements for effets
    const statutSelectEffets = document.getElementById('statutFilterEffets');
    const fournisseurSelectEffets = document.getElementById('fournisseurFilterEffets');
    const banqueSelectEffets = document.getElementById('banqueFilterEffets');

    // Get filter elements for payavenirs
    const statutSelectPayavenirs = document.getElementById('statutFilterPaiment');
    const fournisseurSelectPayavenirs = document.getElementById('fournisseurFilterPaiment');
    const banqueSelectPayavenirs = document.getElementById('banqueFilterPaiment');

    // Get filter elements for recavenirs
    const statutSelectRecavenirs = document.getElementById('statutFilterRecette');
    const clientSelectRecavenirs = document.getElementById('clientFilterRecette');
    const banqueSelectRecavenirs = document.getElementById('banqueFilterRecette');
    
    // Get solde inputs
    const soldeInputs = document.querySelectorAll('input[name="positive[]"], input[name="negative[]"], input[name="dmlt[]"]');
    
    // Get row elements
    const chequesRows = document.querySelectorAll('.cheque-row');
    const effetsRows = document.querySelectorAll('.effet-row');
    const payavenirsRows = document.querySelectorAll('.payavenir-row');
    const recavenirsRows = document.querySelectorAll('.recavenir-row');

    // Update totalMontant for chèques
    function updateTotalMontantCheques() {
      let total = 0;
      
      chequesRows.forEach(row => {
        if (row.style.display !== 'none') {
          const montantCell = row.querySelector('.montant');
          if (montantCell) {
            const raw = montantCell.textContent;
            const montant = parseFloat(raw.replace(/\s/g, '').replace(',', '.'));
            if (!isNaN(montant)) total += montant;
          }
        }
      });

      const totalCell = document.getElementById('totalMontantCellCheques');
      if (totalCell) {
        totalCell.textContent = total.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      }
      
      // Update display total
      const displayTotal = document.getElementById('displayTotalCheques');
      if (displayTotal) {
        displayTotal.textContent = total.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      }
      
      updateGeneralTotal();
    }

    // Update totalMontant for effets
    function updateTotalMontantEffets() {
      let total = 0;
      
      effetsRows.forEach(row => {
        if (row.style.display !== 'none') {
          const montantCell = row.querySelector('.montant');
          if (montantCell) {
            const raw = montantCell.textContent;
            const montant = parseFloat(raw.replace(/\s/g, '').replace(',', '.'));
            if (!isNaN(montant)) total += montant;
          }
        }
      });

      const totalCell = document.getElementById('totalMontantCellEffets');
      if (totalCell) {
        totalCell.textContent = total.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      }
      
      // Update display total
      const displayTotal = document.getElementById('displayTotalEffets');
      if (displayTotal) {
        displayTotal.textContent = total.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      }
      
      updateGeneralTotal();
    }

    // Update totalMontant for payavenirs
    function updateTotalMontantPayavenirs() {
      let total = 0;
      
      payavenirsRows.forEach(row => {
        if (row.style.display !== 'none') {
          const montantCell = row.querySelector('.montant');
          if (montantCell) {
            const raw = montantCell.textContent;
            const montant = parseFloat(raw.replace(/\s/g, '').replace(',', '.'));
            if (!isNaN(montant)) total += montant;
          }
        }
      });

      const totalCell = document.getElementById('totalMontantCellPayavenirs');
      if (totalCell) {
        totalCell.textContent = total.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      }
      
      // Update display total
      const displayTotal = document.getElementById('displayTotalPayavenirs');
      if (displayTotal) {
        displayTotal.textContent = total.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      }
      
      updateGeneralTotal();
    }

    // Update general total (chèques + effets + payavenirs)
    function updateGeneralTotal() {
      const chequesTotal = parseFloat(document.getElementById('displayTotalCheques')?.textContent?.replace(/\s/g, '').replace(',', '.')) || 0;
      const effetsTotal = parseFloat(document.getElementById('displayTotalEffets')?.textContent?.replace(/\s/g, '').replace(',', '.')) || 0;
      const payavenirsTotal = parseFloat(document.getElementById('displayTotalPayavenirs')?.textContent?.replace(/\s/g, '').replace(',', '.')) || 0;
      const generalTotal = chequesTotal + effetsTotal + payavenirsTotal;
      
      const displayGeneralTotal = document.getElementById('displayTotalGeneral');
      if (displayGeneralTotal) {
        displayGeneralTotal.textContent = generalTotal.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      }
    }

    // Filter chèques rows
    function filterChequesRows() {
      const selectedStatut = statutSelectCheques.value.toLowerCase();
      const selectedFournisseur = fournisseurSelectCheques.value.toLowerCase();
      const selectedBanque = banqueSelectCheques.value.toLowerCase();
      let visibleRowCount = 0;
      
      chequesRows.forEach(row => {
        const rowStatut = row.getAttribute('data-statut').toLowerCase();
        const rowFournisseur = row.getAttribute('data-fournisseur').toLowerCase();
        const rowBanque = row.getAttribute('data-banque').toLowerCase();

        const showStatut = !selectedStatut || rowStatut === selectedStatut;
        const showFournisseur = !selectedFournisseur || rowFournisseur === selectedFournisseur;
        const showBanque = !selectedBanque || rowBanque === selectedBanque;

        if (showStatut && showFournisseur && showBanque) {
          row.style.display = '';
          visibleRowCount++;
        } else {
          row.style.display = 'none';
        }
      });

      // Show/hide "no results" row for chèques
      let msg = document.getElementById('noChequeMsg');
      if (visibleRowCount === 0) {
        if (!msg) {
          msg = document.createElement('tr');
          msg.id = 'noChequeMsg';
          msg.innerHTML = `<td colspan="6" class="text-muted text-center">Aucun chèque trouvé pour ce filtre.</td>`;
          document.querySelector('#chequesTable tbody').appendChild(msg);
        }
      } else {
        if (msg) msg.remove();
      }

      updateTotalMontantCheques();
    }

    // Filter effets rows
    function filterEffetsRows() {
      const selectedStatut = statutSelectEffets.value.toLowerCase();
      const selectedFournisseur = fournisseurSelectEffets.value.toLowerCase();
      const selectedBanque = banqueSelectEffets.value.toLowerCase();
      let visibleRowCount = 0;

      effetsRows.forEach(row => {
        const rowStatut = row.getAttribute('data-statut').toLowerCase();
        const rowFournisseur = row.getAttribute('data-fournisseur').toLowerCase();
        const rowBanque = row.getAttribute('data-banque').toLowerCase();

        const showStatut = !selectedStatut || rowStatut === selectedStatut;
        const showFournisseur = !selectedFournisseur || rowFournisseur === selectedFournisseur;
        const showBanque = !selectedBanque || rowBanque === selectedBanque;

        if (showStatut && showFournisseur && showBanque) {
          row.style.display = '';
          visibleRowCount++;
        } else {
          row.style.display = 'none';
        }
      });

      // Show/hide "no results" row for payavenirs
      let msg = document.getElementById('noPayavenirMsg');
      if (visibleRowCount === 0) {
        if (!msg) {
          msg = document.createElement('tr');
          msg.id = 'noPayavenirMsg';
          msg.innerHTML = `<td colspan="6" class="text-muted text-center">Aucun effet trouvé pour ce filtre.</td>`;
          document.querySelector('#effetsTable tbody').appendChild(msg);
        }
      } else {
        if (msg) msg.remove();
      }

      updateTotalMontantEffets();
    }

    // Filter payavenirs rows
    function filterPayavenirsRows() {
      const selectedStatut = statutSelectPayavenirs.value.toLowerCase();
      const selectedFournisseur = fournisseurSelectPayavenirs.value.toLowerCase();
      const selectedBanque = banqueSelectPayavenirs.value.toLowerCase();
      let visibleRowCount = 0;

      payavenirsRows.forEach(row => {
        const rowStatut = row.getAttribute('data-statut').toLowerCase();
        const rowFournisseur = row.getAttribute('data-fournisseur').toLowerCase();
        const rowBanque = row.getAttribute('data-banque').toLowerCase();

        const showStatut = !selectedStatut || rowStatut === selectedStatut;
        const showFournisseur = !selectedFournisseur || rowFournisseur === selectedFournisseur;
        const showBanque = !selectedBanque || rowBanque === selectedBanque;

        if (showStatut && showFournisseur && showBanque) {
          row.style.display = '';
          visibleRowCount++;
        } else {
          row.style.display = 'none';
        }
      });

      // Show/hide "no results" row for payavenirs
      let msg = document.getElementById('noPayavenirMsg');
      if (visibleRowCount === 0) {
        if (!msg) {
          msg = document.createElement('tr');
          msg.id = 'noPayavenirMsg';
          msg.innerHTML = `<td colspan="6" class="text-muted text-center">Aucun effet trouvé pour ce filtre.</td>`;
          document.querySelector('#payavenirsTable tbody').appendChild(msg);
        }
      } else {
        if (msg) msg.remove();
      }

      updateTotalMontantPayavenirs();
    }

    function filterRecavenirsRows(){
const selectedStatut = statutSelectRecavenirs.value.toLowerCase();
const selectedClient = clientSelectRecavenirs.value.toLowerCase();
const selectedBanque = banqueSelectRecavenirs.value.toLowerCase();
let visibleRowCount = 0;

recavenirsRows.forEach(row => {
  const rowStatut = row.getAttribute('data-statut').toLowerCase();
  const rowClient = row.getAttribute('data-client').toLowerCase();
  const rowBanque = row.getAttribute('data-banque').toLowerCase();

  const showStatut = !selectedStatut || rowStatut === selectedStatut;
  const showClient = !selectedClient || rowClient === selectedClient;
  const showBanque = !selectedBanque || rowBanque === selectedBanque;

  if (showStatut && showClient && showBanque) {
    row.style.display = '';
    visibleRowCount++;
  } else {
    row.style.display = 'none';
  }
});

// Show/hide "no results" row for recavenirs
let msg = document.getElementById('noRecavenirMsg');
if (visibleRowCount === 0) {
  if (!msg) {
    msg = document.createElement('tr');
    msg.id = 'noRecavenirMsg';
    msg.innerHTML = `<td colspan="7" class="text-muted text-center">Aucune recette trouvée pour ce filtre.</td>`;
    document.querySelector('#recavenirsTable tbody').appendChild(msg);
  }
} else {
  if (msg) msg.remove();
}

updateTotalMontantRecavenirs(); // This was missing!
}

// Add filter listeners for recavenirs (add this around line 450 with other event listeners)
// Filter listeners for recavenirs
if (statutSelectRecavenirs) {
statutSelectRecavenirs.addEventListener('change', filterRecavenirsRows);
}
if (clientSelectRecavenirs) {
clientSelectRecavenirs.addEventListener('change', filterRecavenirsRows);
}
if (banqueSelectRecavenirs) {
banqueSelectRecavenirs.addEventListener('change', filterRecavenirsRows);
}
    // Input listeners for solde
    soldeInputs.forEach(input => {
      input.addEventListener('input', () => {
        const id = input.dataset.banqueId;
        const enCirculationCell = document.querySelector(`.en-circulation[data-banque-id="${id}"]`);
        const totalCell = document.querySelector(`.total-solde[data-banque-id="${id}"]`);
        
        if (enCirculationCell && totalCell) {
          const enteredSolde = parseFloat(input.value) || 0;
          const enCirculation = parseFloat(enCirculationCell.textContent) || 0;
          const total = enteredSolde + enCirculation;

          totalCell.textContent = total.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
          totalCell.classList.toggle('text-danger', total < 0);
          totalCell.classList.toggle('text-success', total >= 0);
        }
      });
    });

    // Filter listeners for chèques
    if (statutSelectCheques) {
      statutSelectCheques.addEventListener('change', filterChequesRows);
    }
    if (fournisseurSelectCheques) {
      fournisseurSelectCheques.addEventListener('change', filterChequesRows);
    }
    if (banqueSelectCheques) {
      banqueSelectCheques.addEventListener('change', filterChequesRows);
    }

    // Filter listeners for effets
    if (statutSelectEffets) {
      statutSelectEffets.addEventListener('change', filterEffetsRows);
    }
    if (fournisseurSelectEffets) {
      fournisseurSelectEffets.addEventListener('change', filterEffetsRows);
    }
    if (banqueSelectEffets) {
      banqueSelectEffets.addEventListener('change', filterEffetsRows);
    }

    // Filter listeners for payavenirs
    if (statutSelectPayavenirs) {
      statutSelectPayavenirs.addEventListener('change', filterPayavenirsRows);
    }
    if (fournisseurSelectPayavenirs) {
      fournisseurSelectPayavenirs.addEventListener('change', filterPayavenirsRows);
    }
    if (banqueSelectPayavenirs) {
      banqueSelectPayavenirs.addEventListener('change', filterPayavenirsRows);
    }

    // Initial run
    filterChequesRows();
    filterEffetsRows();
    filterPayavenirsRows();
    filterRecavenirsRows();
    updateGeneralTotal();
  });

  // Helper function to properly format numbers in French format
  function formatFrenchNumber(value) {
    if (!value) return '0,00';
    
    // Convert to string and clean it
    let cleanValue = value.toString().replace(/\s/g, '').replace(/[^\d,.-]/g, '');
    
    // Handle different decimal separators
    if (cleanValue.includes(',')) {
      cleanValue = cleanValue.replace(',', '.');
    }
    
    const numValue = parseFloat(cleanValue);
    if (isNaN(numValue)) return '0,00';
    
    // Format with French locale: space as thousand separator, comma as decimal
    return numValue.toLocaleString('fr-FR', { 
      minimumFractionDigits: 2, 
      maximumFractionDigits: 2 
    });
  }

  // Helper function to parse French formatted numbers back to float
  function parseFrenchNumber(value) {
    if (!value) return 0;
    
    // Remove spaces and replace comma with dot
    const cleanValue = value.toString().replace(/\s/g, '').replace(',', '.');
    const numValue = parseFloat(cleanValue);
    return isNaN(numValue) ? 0 : numValue;
  }

  function downloadFullPagePDF() {
// Display loading message
const loadingMsg = createLoadingMessage();
document.body.appendChild(loadingMsg);

// Load jsPDF and autoTable plugin sequentially
loadScript('https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js')
  .then(() => loadScript('https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js'))
  .then(() => generatePDF())
  .catch(error => handleError(error, loadingMsg))
  .finally(() => document.body.removeChild(loadingMsg));

// Helper function to create loading message
function createLoadingMessage() {
  const div = document.createElement('div');
  div.innerHTML = '<div class="alert alert-info" style="position: fixed; top: 20px; right: 20px; z-index: 1000;">Génération du PDF complet en cours...</div>';
  return div;
}

// Helper function to load scripts dynamically
function loadScript(src) {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = src;
    script.onload = resolve;
    script.onerror = () => reject(new Error(`Failed to load script: ${src}`));
    document.head.appendChild(script);
  });
}

// Helper function to format numbers in French format with space instead of '/'
function formatFrenchNumber(value) {
  if (isNaN(value)) return '0,00';
  return value
    .toFixed(2)
    .replace(/\B(?=(\d{3})+(?!\d))/g, ' ') // Use space as thousand separator
    .replace('.', ','); // Use comma for decimal
}

// Helper function to parse French number strings
function parseFrenchNumber(text) {
  if (!text) return 0;
  // Remove any '/' and replace with space, then handle standard French format
  return parseFloat(text.replace(/[\/\s]/g, '').replace(',', '.')) || 0;
}

// Helper function to add a section table
function addSectionTable(pdf, title, headers, data, yPosition, columnStyles, hasTotals = true) {
  if (yPosition > 220) {
    pdf.addPage();
    yPosition = 20;
  }

  pdf.setFontSize(16);
  pdf.text(title, 20, yPosition);
  yPosition += 10;

  if (data.length > 0) {
    pdf.autoTable({
      head: [headers],
      body: data,
      startY: yPosition,
      theme: 'striped',
      styles: { fontSize: 8, cellPadding: 2 },
      headStyles: { fillColor: [52, 144, 220], textColor: 255, fontStyle: 'bold' },
      columnStyles,
      didParseCell: (data) => {
        if (hasTotals && data.row.index === data.table.body.length - 1) {
          data.cell.styles.fontStyle = 'bold';
          data.cell.styles.fillColor = [240, 240, 240];
        }
      },
    });
    return pdf.lastAutoTable.finalY + 20;
  } else {
    pdf.setFontSize(10);
    pdf.text(`Aucun élément trouvé pour cette période.`, 20, yPosition);
    return yPosition + 15;
  }
}

// Main function to generate the PDF
function generatePDF() {
  const { jsPDF } = window.jspdf;
  const pdf = new jsPDF('p', 'mm', 'a4');

  // Add header and date
  pdf.setFontSize(20);
  pdf.text('Situation Bancaire Complète', 20, 20);
  pdf.setFontSize(12);
  pdf.text(`Date: ${new Date().toLocaleDateString('fr-FR')}`, 20, 30);
  let yPosition = 45;

  // Section 1: Situation Bancaire
  const bankData = [];
let totalPositive = 0, totalNegative = 0, totalDmlt = 0;

// Select all rows in the table body
document.querySelectorAll('#situationBancaire tbody tr').forEach(row => {
const cells = row.querySelectorAll('td');
if (cells.length >= 5) {
  // Extract bank name from the first cell (strong tag or text)
  const bankName = cells[0].querySelector('strong')?.textContent.trim() || cells[0].textContent.trim();
  
  // Extract values from input fields
  const positiveInput = cells[1].querySelector('input[name="positive[]"]');
  const negativeInput = cells[2].querySelector('input[name="negative[]"]');
  const dmltInput = cells[4].querySelector('input[name="dmlt[]"]');

  // Parse numeric values, default to 0 if invalid or empty
  const positive = parseFloat(positiveInput?.value.replace(/\s/g, '') || 0);
  const negative = parseFloat(negativeInput?.value.replace(/\s/g, '') || 0);
  const dmlt = parseFloat(dmltInput?.value.replace(/\s/g, '') || 0);

  // Only include valid rows with a bank name
  if (bankName) {
    bankData.push([
      bankName,
      formatFrenchNumber(positive),
      formatFrenchNumber(negative),
      formatFrenchNumber(dmlt),
    ]);
    totalPositive += positive;
    totalNegative += negative;
    totalDmlt += dmlt;
  }
}
});

// Add totals row
bankData.push([
'TOTAL',
formatFrenchNumber(totalPositive),
formatFrenchNumber(totalNegative),
formatFrenchNumber(totalDmlt),
]);

// Add to PDF
yPosition = addSectionTable(
pdf,
'1. Situation Bancaire',
['Banque', 'Solde Positif', 'Solde Négatif', 'Dette Moyen Long Terme'],
bankData,
yPosition,
{ 0: { halign: 'left' }, 1: { halign: 'right' }, 2: { halign: 'right' }, 3: { halign: 'right' } }
);

// Optional: Helper function to format numbers in French format
function formatFrenchNumber(number) {
return number.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
  // Section 2: Chèques en circulation
  const visibleCheques = [];
  let chequesTotalAmount = 0;

  document.querySelectorAll('.cheque-row').forEach(row => {
    if (row.style.display !== 'none') {
      const cells = row.querySelectorAll('td');
      if (cells.length >= 6) {
        const montantValue = parseFrenchNumber(cells[1].textContent.trim());
        chequesTotalAmount += montantValue;
        visibleCheques.push([
          cells[0].textContent.trim(),
          formatFrenchNumber(montantValue),
          cells[2].textContent.trim(),
          cells[3].textContent.trim(),
          cells[4].textContent.trim(),
          cells[5].textContent.trim(),
        ]);
      }
    }
  });

  if (visibleCheques.length > 0) {
    visibleCheques.push(['TOTAL', formatFrenchNumber(chequesTotalAmount), '', '', '', '']);
  }

  yPosition = addSectionTable(
    pdf,
    '2. Chèques en circulation',
    ['Numéro', 'Montant', 'Date Échéance', 'Bénéficiaire', 'Banque', 'Statut'],
    visibleCheques,
    yPosition,
    {
      0: { halign: 'left', cellWidth: 25 },
      1: { halign: 'right', cellWidth: 25 },
      2: { halign: 'center', cellWidth: 25 },
      3: { halign: 'left', cellWidth: 40 },
      4: { halign: 'left', cellWidth: 30 },
      5: { halign: 'center', cellWidth: 25 },
    }
  );

  // Section 3: Effets en circulation
  const visibleEffets = [];
  let effetsTotalAmount = 0;

  document.querySelectorAll('.effet-row').forEach(row => {
    if (row.style.display !== 'none') {
      const cells = row.querySelectorAll('td');
      if (cells.length >= 6) {
        const montantValue = parseFrenchNumber(cells[1].textContent.trim());
        effetsTotalAmount += montantValue;
        visibleEffets.push([
          cells[0].textContent.trim(),
          formatFrenchNumber(montantValue),
          cells[2].textContent.trim(),
          cells[3].textContent.trim(),
          cells[4].textContent.trim(),
          cells[5].textContent.trim(),
        ]);
      }
    }
  });

  if (visibleEffets.length > 0) {
    visibleEffets.push(['TOTAL', formatFrenchNumber(effetsTotalAmount), '', '', '', '']);
  }

  yPosition = addSectionTable(
    pdf,
    '3. Effets en circulation',
    ['Numéro', 'Montant', 'Date Échéance', 'Bénéficiaire', 'Banque', 'Statut'],
    visibleEffets,
    yPosition,
    {
      0: { halign: 'left', cellWidth: 25 },
      1: { halign: 'right', cellWidth: 25 },
      2: { halign: 'center', cellWidth: 25 },
      3: { halign: 'left', cellWidth: 40 },
      4: { halign: 'left', cellWidth: 30 },
      5: { halign: 'center', cellWidth: 25 },
    }
  );

  // Section 4: Paiements à venir
  const visiblePayavenirs = [];
  let payavenirsTotalAmount = 0;

  document.querySelectorAll('.payavenir-row').forEach(row => {
    if (row.style.display !== 'none') {
      const cells = row.querySelectorAll('td');
      if (cells.length >= 7) {
        const montantValue = parseFrenchNumber(cells[1].textContent.trim());
        payavenirsTotalAmount += montantValue;
        visiblePayavenirs.push([
          cells[0].textContent.trim(),
          formatFrenchNumber(montantValue),
          cells[2].textContent.trim(),
          cells[3].textContent.trim(),
          cells[4].textContent.trim(),
          cells[5].textContent.trim(),
          cells[6].textContent.trim(),
        ]);
      }
    }
  });

  if (visiblePayavenirs.length > 0) {
    visiblePayavenirs.push(['TOTAL', formatFrenchNumber(payavenirsTotalAmount), '', '', '', '', '']);
  }

  yPosition = addSectionTable(
    pdf,
    '4. Paiements à venir',
    ['Désignation', 'Montant', 'Date Échéance', 'Statut', 'Date Paiement', 'Fournisseur', 'Banque'],
    visiblePayavenirs,
    yPosition,
    {
      0: { halign: 'left', cellWidth: 35 },
      1: { halign: 'right', cellWidth: 25 },
      2: { halign: 'center', cellWidth: 25 },
      3: { halign: 'center', cellWidth: 20 },
      4: { halign: 'center', cellWidth: 25 },
      5: { halign: 'left', cellWidth: 30 },
      6: { halign: 'left', cellWidth: 25 },
    }
  );

  // Section 5: Résumé Général
  if (yPosition > 220) {
    pdf.addPage();
    yPosition = 20;
  }

  pdf.setFontSize(16);
  pdf.text('5. Résumé Général', 20, yPosition);
  yPosition += 15;

  const generalTotal = chequesTotalAmount + effetsTotalAmount + payavenirsTotalAmount;
  const summaryData = [
    ['Total Chèques', formatFrenchNumber(chequesTotalAmount)],
    ['Total Effets', formatFrenchNumber(effetsTotalAmount)],
    ['Total Paiements à venir', formatFrenchNumber(payavenirsTotalAmount)],
    ['TOTAL GÉNÉRAL', formatFrenchNumber(generalTotal)],
  ];

  pdf.autoTable({
    head: [['Description', 'Montant']],
    body: summaryData,
    startY: yPosition,
    theme: 'striped',
    styles: { fontSize: 12, cellPadding: 4 },
    headStyles: { fillColor: [52, 144, 220], textColor: 255, fontStyle: 'bold' },
    columnStyles: {
      0: { halign: 'left', cellWidth: 80 },
      1: { halign: 'right', cellWidth: 50 },
    },
    didParseCell: (data) => {
      if (data.row.index === 3) {
        data.cell.styles.fontStyle = 'bold';
        data.cell.styles.fillColor = [76, 175, 80];
        data.cell.styles.textColor = 255;
        data.cell.styles.fontSize = 14;
      }
    },
  });

  // Add footer statistics
  const finalY = pdf.lastAutoTable.finalY + 15;
  pdf.setFontSize(10);
  pdf.text(`Nombre de chèques: ${visibleCheques.length > 0 ? visibleCheques.length - 1 : 0}`, 20, finalY);
  pdf.text(`Nombre d'effets: ${visibleEffets.length > 0 ? visibleEffets.length - 1 : 0}`, 20, finalY + 8);
  pdf.text(`Nombre de paiements à venir: ${visiblePayavenirs.length > 0 ? visiblePayavenirs.length - 1 : 0}`, 20, finalY + 16);
  pdf.text(`Généré le: ${new Date().toLocaleString('fr-FR')}`, 20, finalY + 24);

  // Save the PDF
  pdf.save(`situation-bancaire-complete-${new Date().toISOString().split('T')[0]}.pdf`);
}

// Error handling function
function handleError(error, loadingMsg) {
  console.error('Error generating complete PDF:', error);
  if (loadingMsg && document.body.contains(loadingMsg)) {
    document.body.removeChild(loadingMsg);
  }
  alert(`Erreur lors de la génération du PDF complet: ${error.message}`);
}
}

  function downloadChequesPDF() {
// Show loading
const loadingMsg = document.createElement('div');
loadingMsg.innerHTML = '<div class="alert alert-info">Génération du PDF chèques...</div>';
document.body.appendChild(loadingMsg);

const script = document.createElement('script');
script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
script.onload = function() {
  try {
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF('l', 'mm', 'a4'); // Landscape for better table fit
    
    // Add title
    pdf.setFontSize(18);
    pdf.text('Chèques en circulation', 20, 20);
    
    // Add date
    pdf.setFontSize(10);
    pdf.text('Date: ' + new Date().toLocaleDateString('fr-FR'), 20, 30);
    
    // Get visible cheques data
    const visibleCheques = [];
    const chequeRows = document.querySelectorAll('.cheque-row');
    let totalAmount = 0;
    
    chequeRows.forEach(row => {
      if (row.style.display !== 'none') {
        const cells = row.querySelectorAll('td');
        if (cells.length >= 6) {
          const montantText = cells[1].textContent.trim();
          const montantValue = parseFrenchNumber(montantText.replace(/[\/]/g, ' '));

          totalAmount += montantValue;
          
          // Replace '/' with space in all cell content and normalize spaces
          visibleCheques.push([
            cells[0].textContent.trim().replace(/\//g, ' ').replace(/\s+/g, ' '), // Numéro
            formatFrenchNumber(montantValue).replace(/\//g, ' ').replace(/\s+/g, ' '), // Montant
            cells[2].textContent.trim().replace(/\//g, ' ').replace(/\s+/g, ' '), // Date Échéance
            cells[3].textContent.trim().replace(/\//g, ' ').replace(/\s+/g, ' '), // Bénéficiaire
            cells[4].textContent.trim().replace(/\//g, ' ').replace(/\s+/g, ' '), // Banque
            cells[5].textContent.trim().replace(/\//g, ' ').replace(/\s+/g, ' ') // Statut
          ]);
        }
      }
    });

    // Table setup
    let yPosition = 45;
    const columnWidths = [35, 35, 35, 60, 50, 30];
    const startX = 20;
    const cellHeight = 8;
    
    // Headers
    pdf.setFontSize(9);
    pdf.setFont(undefined, 'bold');
    const headers = ['Numéro', 'Montant', 'Date Échéance', 'Bénéficiaire', 'Banque', 'Statut'];
    
    // Draw header cells
    let currentX = startX;
    headers.forEach((header, index) => {
      pdf.rect(currentX, yPosition - 6, columnWidths[index], cellHeight);
      pdf.text(header, currentX + 2, yPosition);
      currentX += columnWidths[index];
    });
    yPosition += cellHeight;
    
    // Data rows
    pdf.setFont(undefined, 'normal');
    pdf.setFontSize(8);
    
    visibleCheques.forEach((row) => {
      if (yPosition > 180) { // Check if we need a new page
        pdf.addPage();
        yPosition = 20;
        
        // Redraw headers on new page
        currentX = startX;
        pdf.setFont(undefined, 'bold');
        headers.forEach((header, index) => {
          pdf.rect(currentX, yPosition - 6, columnWidths[index], cellHeight);
          pdf.text(header, currentX + 2, yPosition);
          currentX += columnWidths[index];
        });
        yPosition += cellHeight;
        pdf.setFont(undefined, 'normal');
      }
      
      currentX = startX;
      row.forEach((cell, cellIndex) => {
        const text = cell.toString();
        // Truncate long text
        const maxLength = cellIndex === 3 ? 25 : 15;
        const displayText = text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
        pdf.rect(currentX, yPosition - 6, columnWidths[cellIndex], cellHeight);
        pdf.text(displayText, currentX + 2, yPosition);
        currentX += columnWidths[cellIndex];
      });
      yPosition += cellHeight;
    });
    
    // Add total
    yPosition += 5;
    pdf.line(startX, yPosition, startX + 70, yPosition);
    yPosition += 8;
    pdf.setFont(undefined, 'bold');
    pdf.setFontSize(10);
    pdf.text(`Total: ${formatFrenchNumber(totalAmount).replace(/\//g, ' ').replace(/\s+/g, ' ')}`, startX, yPosition);
    
    // Add summary
    yPosition += 15;
    pdf.setFontSize(8);
    pdf.setFont(undefined, 'normal');
    pdf.text(`Nombre de chèques: ${visibleCheques.length}`, startX, yPosition);
    
    pdf.save('cheques-en-circulation.pdf');
    document.body.removeChild(loadingMsg);
  } catch (error) {
    console.error('Error:', error);
    document.body.removeChild(loadingMsg);
    alert('Erreur lors de la génération du PDF des chèques');
  }
};
document.head.appendChild(script);
} 

function downloadEffetsPDF() {
// Show loading
const loadingMsg = document.createElement('div');
loadingMsg.innerHTML = '<div class="alert alert-info">Génération du PDF effets...</div>';
document.body.appendChild(loadingMsg);

const script = document.createElement('script');
script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
script.onload = function() {
  try {
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF('l', 'mm', 'a4'); // Landscape
    
    // Add title
    pdf.setFontSize(18);
    pdf.text('Effets en circulation', 20, 20);
    
    // Add date
    pdf.setFontSize(10);
    pdf.text('Date: ' + new Date().toLocaleDateString('fr-FR'), 20, 30);
    
    // Get visible effets data
    const visibleEffets = [];
    const effetRows = document.querySelectorAll('.effet-row');
    let totalAmount = 0;
    
    effetRows.forEach(row => {
      if (row.style.display !== 'none') {
        const cells = row.querySelectorAll('td');
        if (cells.length >= 6) {
          const montantText = cells[1].textContent.trim().replace(/\s/g, '');
          const montantValue = parseFrenchNumber(montantText);
          totalAmount += montantValue;
          
          visibleEffets.push([
            cells[0].textContent.trim(),
            formatFrenchNumber(montantValue).replace(/\//g, ' '), // Replace / with space
            cells[2].textContent.trim(),
            cells[3].textContent.trim(),
            cells[4].textContent.trim(),
            cells[5].textContent.trim()
          ]);
        }
      }
    });

    // Table setup
    let yPosition = 45;
    const columnWidths = [35, 35, 35, 60, 50, 30];
    const startX = 20;
    
    // Headers
    pdf.setFontSize(9);
    pdf.setFont(undefined, 'bold');
    const headers = ['Numéro', 'Montant', 'Date Échéance', 'Bénéficiaire', 'Banque', 'Statut'];
    
    // Draw table header background
    pdf.setFillColor(200, 200, 200);
    pdf.rect(startX, yPosition - 4, columnWidths.reduce((a, b) => a + b, 0), 8, 'F');
    
    // Draw header text
    let currentX = startX;
    headers.forEach((header, index) => {
      pdf.text(header, currentX + 2, yPosition + 2);
      currentX += columnWidths[index];
    });
    
    // Draw table borders
    currentX = startX;
    pdf.setLineWidth(0.2);
    headers.forEach((_, index) => {
      pdf.rect(currentX, yPosition - 4, columnWidths[index], 8);
      currentX += columnWidths[index];
    });
    
    yPosition += 8;
    
    // Data rows
    pdf.setFont(undefined, 'normal');
    pdf.setFontSize(8);
    
    visibleEffets.forEach((row, index) => {
      if (yPosition > 180) { // Check if we need a new page
        pdf.addPage();
        yPosition = 20;
        
        // Redraw headers on new page
        pdf.setFillColor(200, 200, 200);
        pdf.rect(startX, yPosition - 4, columnWidths.reduce((a, b) => a + b, 0), 8, 'F');
        currentX = startX;
        headers.forEach((header, index) => {
          pdf.text(header, currentX + 2, yPosition + 2);
          pdf.rect(currentX, yPosition - 4, columnWidths[index], 8);
          currentX += columnWidths[index];
        });
        yPosition += 8;
      }
      
      currentX = startX;
      row.forEach((cell, cellIndex) => {
        const text = cell.toString();
        // Truncate long text
        const maxLength = cellIndex === 3 ? 25 : 15;
        const displayText = text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
        pdf.text(displayText, currentX + 2, yPosition + 2);
        // Draw cell border
        pdf.rect(currentX, yPosition - 4, columnWidths[cellIndex], 8);
        currentX += columnWidths[cellIndex];
      });
      yPosition += 8;
    });
    
    // Add total
    yPosition += 5;
    pdf.line(startX, yPosition, startX + 70, yPosition);
    yPosition += 8;
    pdf.setFont(undefined, 'bold');
    pdf.setFontSize(10);
    pdf.text(`Total: ${formatFrenchNumber(totalAmount).replace(/\//g, ' ')}`, startX, yPosition); // Replace / with space
    
    // Add summary
    yPosition += 15;
    pdf.setFontSize(8);
    pdf.setFont(undefined, 'normal');
    pdf.text(`Nombre d'effets: ${visibleEffets.length}`, startX, yPosition);
    
    pdf.save('effets-en-circulation.pdf');
    document.body.removeChild(loadingMsg);
  } catch (error) {
    console.error('Error:', error);
    document.body.removeChild(loadingMsg);
    alert('Erreur lors de la génération du PDF des effets');
  }
};
document.head.appendChild(script);
}

function downloadPayavenirsPDF() {
// Show loading
const loadingMsg = document.createElement('div');
loadingMsg.innerHTML = '<div class="alert alert-info">Génération du PDF paiements à venir...</div>';
document.body.appendChild(loadingMsg);

const script = document.createElement('script');
script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
script.onload = function() {
  try {
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF('l', 'mm', 'a4'); // Landscape
    
    // Add title
    pdf.setFontSize(18);
    pdf.text('Paiements à venir', 20, 20);
    
    // Add date
    pdf.setFontSize(10);
    pdf.text('Date: ' + new Date().toLocaleDateString('fr-FR'), 20, 30);
    
    // Get visible payavenirs data
    const visiblePayavenirs = [];
    const payavenirRows = document.querySelectorAll('.payavenir-row');
    let totalAmount = 0;
    
    payavenirRows.forEach(row => {
      if (row.style.display !== 'none') {
        const cells = row.querySelectorAll('td');
        if (cells.length >= 7) {
          const montantText = cells[1].textContent.trim();
          const montantValue = parseFrenchNumber(montantText.replace(/\s/g, ''));
          totalAmount += montantValue;
          
          visiblePayavenirs.push([
            cells[0].textContent.trim(),
            formatFrenchNumber(montantValue),
            cells[2].textContent.trim(),
            cells[3].textContent.trim(),
            cells[4].textContent.trim(),
            cells[5].textContent.trim(),
            cells[6].textContent.trim()
          ]);
        }
      }
    });

    // Table setup
    let yPosition = 45;
    const columnWidths = [40, 30, 30, 25, 30, 40, 30];
    const startX = 15;
    
    // Headers
    pdf.setFontSize(8);
    pdf.setFont(undefined, 'bold');
    const headers = ['Désignation', 'Montant', 'Date Échéance', 'Statut', 'Date Paiement', 'Fournisseur', 'Banque'];
    
    // Draw table headers with borders
    pdf.setLineWidth(0.2);
    let currentX = startX;
    headers.forEach((header, index) => {
      pdf.rect(currentX, yPosition - 5, columnWidths[index], 7); // Draw cell
      pdf.text(header, currentX + 1, yPosition);
      currentX += columnWidths[index];
    });
    yPosition += 7;
    
    // Data rows
    pdf.setFont(undefined, 'normal');
    pdf.setFontSize(7);
    
    visiblePayavenirs.forEach((row, index) => {
      if (yPosition > 180) { // Check if we need a new page
        pdf.addPage();
        yPosition = 20;
        
        // Redraw headers on new page
        pdf.setFontSize(8);
        pdf.setFont(undefined, 'bold');
        currentX = startX;
        headers.forEach((header, index) => {
          pdf.rect(currentX, yPosition - 5, columnWidths[index], 7);
          pdf.text(header, currentX + 1, yPosition);
          currentX += columnWidths[index];
        });
        yPosition += 7;
      }
      
      currentX = startX;
      row.forEach((cell, cellIndex) => {
        const text = cell.toString();
        // Truncate long text
        let maxLength;
        switch(cellIndex) {
          case 0: maxLength = 20; break; // Désignation
          case 5: maxLength = 20; break; // Fournisseur
          default: maxLength = 15; break;
        }
        const displayText = text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
        pdf.rect(currentX, yPosition - 5, columnWidths[cellIndex], 7); // Draw cell
        pdf.text(displayText, currentX + 1, yPosition);
        currentX += columnWidths[cellIndex];
      });
      yPosition += 7;
    });
    
    // Add total
    yPosition += 5;
    pdf.line(startX, yPosition, startX + 70, yPosition);
    yPosition += 8;
    pdf.setFont(undefined, 'bold');
    pdf.setFontSize(10);
    pdf.text(`Total: ${formatFrenchNumber(totalAmount)}`, startX, yPosition);
    
    // Add summary
    yPosition += 15;
    pdf.setFontSize(8);
    pdf.setFont(undefined, 'normal');
    pdf.text(`Nombre de paiements à venir: ${visiblePayavenirs.length}`, startX, yPosition);
    
    pdf.save('paiements-a-venir.pdf');
    document.body.removeChild(loadingMsg);
  } catch (error) {
    console.error('Error:', error);
    document.body.removeChild(loadingMsg);
    alert('Erreur lors de la génération du PDF des paiements à venir');
  }
};
document.head.appendChild(script);
}

function downloadRecettesPDF() {
// Show loading
const loadingMsg = document.createElement('div');
loadingMsg.innerHTML = '<div class="alert alert-info">Génération du PDF recettes...</div>';
document.body.appendChild(loadingMsg);

const script = document.createElement('script');
script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
script.onload = function() {
  try {
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF('l', 'mm', 'a4'); // Landscape
    
    // Add title
    pdf.setFontSize(18);
    pdf.text('Recettes à venir', 20, 20);
    
    // Add date
    pdf.setFontSize(10);
    pdf.text('Date: ' + new Date().toLocaleDateString('fr-FR'), 20, 30);
    
    // Get visible recavenirs data
    const visibleRecettes = [];
    const recetteRows = document.querySelectorAll('.recavenir-row');
    let totalAmount = 0;
    
    recetteRows.forEach(row => {
      if (row.style.display !== 'none') {
        const cells = row.querySelectorAll('td');
        if (cells.length >= 7) {
          const montantText = cells[1].textContent.trim();
          const montantValue = parseFrenchNumber(montantText.replace(/\s/g, ''));
          totalAmount += montantValue;
          
          visibleRecettes.push([
            cells[0].textContent.trim(), // Designation
            formatFrenchNumber(montantValue), // Montant
            cells[2].textContent.trim(), // Date Echéance
            cells[3].textContent.trim(), // Statut
            cells[4].textContent.trim(), // Date de paiement
            cells[5].textContent.trim(), // Client
            cells[6].textContent.trim()  // Banque
          ]);
        }
      }
    });

    // Table setup
    let yPosition = 45;
    const columnWidths = [40, 30, 30, 25, 30, 40, 30];
    const startX = 15;
    
    // Headers
    pdf.setFontSize(8);
    pdf.setFont(undefined, 'bold');
    const headers = ['Désignation', 'Montant', 'Date Échéance', 'Statut', 'Date Paiement', 'Client', 'Banque'];
    
    // Draw table headers with borders
    pdf.setLineWidth(0.2);
    let currentX = startX;
    headers.forEach((header, index) => {
      pdf.rect(currentX, yPosition - 5, columnWidths[index], 7); // Draw cell
      pdf.text(header, currentX + 1, yPosition);
      currentX += columnWidths[index];
    });
    yPosition += 7;
    
    // Data rows
    pdf.setFont(undefined, 'normal');
    pdf.setFontSize(7);
    
    visibleRecettes.forEach((row, index) => {
      if (yPosition > 180) { // Check if we need a new page
        pdf.addPage();
        yPosition = 20;
        
        // Redraw headers on new page
        pdf.setFontSize(8);
        pdf.setFont(undefined, 'bold');
        currentX = startX;
        headers.forEach((header, index) => {
          pdf.rect(currentX, yPosition - 5, columnWidths[index], 7);
          pdf.text(header, currentX + 1, yPosition);
          currentX += columnWidths[index];
        });
        yPosition += 7;
      }
      
      currentX = startX;
      row.forEach((cell, cellIndex) => {
        const text = cell.toString();
        // Truncate long text
        let maxLength;
        switch(cellIndex) {
          case 0: maxLength = 20; break; // Désignation
          case 5: maxLength = 20; break; // Client
          default: maxLength = 15; break;
        }
        const displayText = text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
        pdf.rect(currentX, yPosition - 5, columnWidths[cellIndex], 7); // Draw cell
        pdf.text(displayText, currentX + 1, yPosition);
        currentX += columnWidths[cellIndex];
      });
      yPosition += 7;
    });
    
    // Add total
    yPosition += 5;
    pdf.line(startX, yPosition, startX + 70, yPosition);
    yPosition += 8;
    pdf.setFont(undefined, 'bold');
    pdf.setFontSize(10);
    pdf.text(`Total: ${formatFrenchNumber(totalAmount)}`, startX, yPosition);
    
    // Add summary
    yPosition += 15;
    pdf.setFontSize(8);
    pdf.setFont(undefined, 'normal');
    pdf.text(`Nombre de recettes à venir: ${visibleRecettes.length}`, startX, yPosition);
    
    pdf.save('recettes-a-venir.pdf');
    document.body.removeChild(loadingMsg);
  } catch (error) {
    console.error('Error:', error);
    document.body.removeChild(loadingMsg);
    alert('Erreur lors de la génération du PDF des recettes à venir');
  }
};
document.head.appendChild(script);
}


function downloadExcel() {
    // Show loading
    const loadingMsg = document.createElement('div');
    loadingMsg.innerHTML = '<div class="alert alert-info">Génération du fichier Excel...</div>';
    document.body.appendChild(loadingMsg);
    
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
    script.onload = function() {
      try {
        const wb = XLSX.utils.book_new();
        
        // Cheques sheet
        const chequesData = [];
        chequesData.push(['Numéro', 'Montant', 'Date Échéance', 'Bénéficiaire', 'Banque', 'Statut']);
        let chequesTotalAmount = 0;
        
        document.querySelectorAll('.cheque-row').forEach(row => {
          if (row.style.display !== 'none') {
            const cells = row.querySelectorAll('td');
            if (cells.length >= 6) {
              const montantText = cells[1].textContent.trim();
              const montantValue = parseFrenchNumber(montantText.replace(/\//g, ''));
              chequesTotalAmount += montantValue;
              
              chequesData.push([
                cells[0].textContent.trim(),
                formatFrenchNumber(montantValue),
                cells[2].textContent.trim(),
                cells[3].textContent.trim(),
                cells[4].textContent.trim(),
                cells[5].textContent.trim()
              ]);
            }
          }
        });
        
        chequesData.push(['TOTAL', formatFrenchNumber(chequesTotalAmount), '', '', '', '']);
        
        const chequesSheet = XLSX.utils.aoa_to_sheet(chequesData);
        XLSX.utils.book_append_sheet(wb, chequesSheet, 'Chèques');
        
        // Effets sheet
        const effetsData = [];
        effetsData.push(['Numéro', 'Montant', 'Date Échéance', 'Bénéficiaire', 'Banque', 'Statut']);
        let effetsTotalAmount = 0;
        
        document.querySelectorAll('.effet-row').forEach(row => {
          if (row.style.display !== 'none') {
            const cells = row.querySelectorAll('td');
            if (cells.length >= 6) {
              const montantText = cells[1].textContent.trim();
              const montantValue = parseFrenchNumber(montantText.replace(/\//g, ''));
              effetsTotalAmount += montantValue;
              
              effetsData.push([
                cells[0].textContent.trim(),
                formatFrenchNumber(montantValue),
                cells[2].textContent.trim(),
                cells[3].textContent.trim(),
                cells[4].textContent.trim(),
                cells[5].textContent.trim()
              ]);
            }
          }
        });
        
        effetsData.push(['TOTAL', formatFrenchNumber(effetsTotalAmount), '', '', '', '']);
        
        const effetsSheet = XLSX.utils.aoa_to_sheet(effetsData);
        XLSX.utils.book_append_sheet(wb, effetsSheet, 'Effets');
        
        // Payavenirs sheet
        const payavenirsData = [];
        payavenirsData.push(['Désignation', 'Montant', 'Date Échéance', 'Statut', 'Date Paiement', 'Fournisseur', 'Banque']);
        let payavenirsTotalAmount = 0;
        
        document.querySelectorAll('.payavenir-row').forEach(row => {
          if (row.style.display !== 'none') {
            const cells = row.querySelectorAll('td');
            if (cells.length >= 7) {
              const montantText = cells[1].textContent.trim();
              const montantValue = parseFrenchNumber(montantText.replace(/\//g, ''));
              payavenirsTotalAmount += montantValue;
              
              payavenirsData.push([
                cells[0].textContent.trim(),
                formatFrenchNumber(montantValue),
                cells[2].textContent.trim(),
                cells[3].textContent.trim(),
                cells[4].textContent.trim(),
                cells[5].textContent.trim(),
                cells[6].textContent.trim()
              ]);
            }
          }
        });
        
        payavenirsData.push(['TOTAL', formatFrenchNumber(payavenirsTotalAmount), '', '', '', '', '']);
        
        const payavenirsSheet = XLSX.utils.aoa_to_sheet(payavenirsData);
        XLSX.utils.book_append_sheet(wb, payavenirsSheet, 'Paiements à venir');
        
        // Summary sheet
        const generalTotal = chequesTotalAmount + effetsTotalAmount + payavenirsTotalAmount;
        const summaryData = [
          ['Résumé Général - Situation Bancaire'],
          ['Date:', new Date().toLocaleDateString('fr-FR')],
          [''],
          ['Type', 'Montant', 'Nombre d\'éléments'],
          ['Total Chèques', formatFrenchNumber(chequesTotalAmount), (chequesData.length - 2).toString()],
          ['Total Effets', formatFrenchNumber(effetsTotalAmount), (effetsData.length - 2).toString()],
          ['Total Paiements à venir', formatFrenchNumber(payavenirsTotalAmount), (payavenirsData.length - 2).toString()],
          [''],
          ['Total Général', formatFrenchNumber(generalTotal), '']
        ];
        
        const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
        XLSX.utils.book_append_sheet(wb, summarySheet, 'Résumé');
        
        // Save file
        XLSX.writeFile(wb, 'situation-bancaire-' + new Date().toISOString().split('T')[0] + '.xlsx');
        document.body.removeChild(loadingMsg);
      } catch (error) {
        console.error('Error:', error);
        document.body.removeChild(loadingMsg);
        alert('Erreur lors de la génération du fichier Excel');
      }
    };
    document.head.appendChild(script);
  }

  function openBanqueModal() {
    $('#banqueModal').modal('show'); // Requires jQuery + Bootstrap JS
  }

  function deleteBanque(id) {
    fetch(`/tresorerie/banques/delete`, {
      method: 'DELETE',
      body: JSON.stringify({ id }),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    .then(response => {
      if (response.ok) {
        alert('Banque supprimée avec succès');
        location.reload();
      } else {
        alert('Erreur lors de la suppression de la banque');
      }
    })
    .catch(error => {
      console.error('Error:', error);
      alert('Erreur lors de la suppression de la banque');
    });
  }
  </script>